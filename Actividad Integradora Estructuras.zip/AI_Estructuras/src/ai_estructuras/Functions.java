package ai_estructuras;

public class Functions {
    
    
    Nodos inicio=null,fin=null;
    
    
    boolean isEmpty(){
        return inicio == null && fin==null;
    }
    
    
    void push(String val,String type){
        Nodos node = new Nodos(val,type);
        if(isEmpty()){
            inicio=node;
            fin=inicio;
        } else if(inicio == fin){
            node.sig=inicio;
            inicio.ant=node;
            inicio=node;
        } else{
            node.sig=inicio;
            inicio.ant=node;
            inicio=node;
        }
    }
    
    
    String popFront(){
        String r="Error Nodo Vacio";
        if(isEmpty()){
            return r;
        }else if(inicio==fin){
            r=inicio.info;
            inicio=null;
            fin=null;
            return r;
        }else {
            r=inicio.info;
            Nodos aux=inicio;
            inicio=inicio.sig;
            inicio.ant=null;
            aux.sig=null;
            return r;
        }
    }
    
    
    
    String popBack(){
        String r="Error Nodo Vacio";
        if(isEmpty()){
            return r;
        }else if(inicio==fin){
            r=inicio.info;
            inicio=null;
            fin=null;
            return r;
        } else{
            r=fin.info;
            Nodos aux=fin;
            fin=fin.ant;
            aux.ant=null;
            fin.sig=null;
            return r;
        }
    }
    
    
    void printRigth(){
        if(isEmpty()){
            System.out.println("Nodo Vacio");
        } else if(inicio==fin){
            System.out.println("Modulo: "+inicio.type+"\t- "+inicio.info );
        } else{
            Nodos node= inicio;
            while (node!=fin) {
                System.out.println("Modulo: "+node.type+"\t- "+node.info );
                node=node.sig;
            }
            System.out.println("Modulo: "+fin.type+"\t- "+fin.info );
        }
        System.out.println("");
    }
    
    
    
    void printLeft(){
        if(isEmpty()){
            System.out.println("Nodo Vacio");
        } else if(inicio==fin){
            System.out.println("Modulo: "+inicio.type+"\t- "+inicio.info );
        } else{
            Nodos node= fin;
            while (node!=null) {
                System.out.println("Modulo: "+node.type+"\t- "+node.info );
                node=node.ant;
            }
        }
        System.out.println("");
    }
    
    

/*    public static void main(String at[]){
        Functions nodo = new Functions();

        nodo.push("H", "char");
        nodo.push("o", "char");
        nodo.push("l", "char");
        nodo.push("a", "char");
        
        nodo.popFront();
        nodo.popBack();
        
        nodo.printRigth();
        System.out.println("____");
        nodo.printLeft();
        
    }
*/
}
