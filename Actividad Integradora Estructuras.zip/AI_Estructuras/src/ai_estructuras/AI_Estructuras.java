package ai_estructuras;


import java.util.Scanner;


public class AI_Estructuras {
    public static void main(String[] args) {
        Functions nodo = new Functions();
        Scanner scanner = new Scanner(System.in);
        /*
        nodo.push("100","Administracion");
        nodo.push("200","Administracion");
        nodo.push("300","Administracion");
        nodo.push("400","Administracion");
        nodo.push("$100 Habitacion: 15","Mantenimiento");
        nodo.push("$200 Habitacion: 15","Mantenimiento");
        nodo.push("N:Alejandra: F:30/06/2022","Eventos      ");
        nodo.push("N:Armando: F:38/07/2022","Eventos      ");
        nodo.push("N:Itzel F:10/06/2022 H:2","Visitas      ");
        nodo.push("N:Itzel F:10/06/2022 H:2","Visitas      ");
        nodo.push("$150.0","Agua y Luz");
        nodo.push("$2.5","Agua y Luz");
        nodo.push("$300-0","Agua y Luz");*/

        
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        
        do {
            System.out.print("1.-Administracion\n"
                    + "2.-Ingreso a los condominios\n"
                    + "3.-Calculo y registro de cuotas de matenimiento e instalaciones\n"
                    + "4.-Gestiòn de eventos de Areas comunes\n"
                    + "5.-Registro de Visitas\n"
                    + "6.-Registro de lectura de consumo de agua y luz\n"
                    + "Que modulo desea ejecutar: "
            );
            
            
            int opc = scanner.nextInt();
            
            String Categoria="";
            String Valor="";
            
            
                        nodo.push(Valor, Categoria);

                        
            switch (opc) {
                case 1:
                    System.out.println("\nAdministracion");
                    do {
                        System.out.print("Ingrese la cantidad a pagar: ");
                        int can = scanner.nextInt();
                        
                        nodo.push(can + "", "Administracion");
                        
                        
                        System.out.print("\n¿Desea Agregar otro pago? 1.Si/2.No: ");
                    } while (scanner.nextInt() == 1);
                    System.out.println("\nAlmacenado");
                    break;
                case 2:
                    System.out.println("\nIngreso");
                    System.out.print("Escriba su usuario: ");
                    String user = "";
                    int c = 0;
                    do {
                        if (c != 0) {
                            System.out.print("Usuario no registrado escriba lo de nuevo: ");
                        }
                        if (c == 3) {
                            System.out.print("*La clave es 'user'*:");
                        }
                        user = scanner.next();
                        c++;
                    } while (!user.equalsIgnoreCase("user"));

                    System.out.println("\nPuede acceder");
                    break;
                case 3:
                    System.out.println("\nMantenimiento");
                    do {
                        System.out.print("Cuota a pagar:");
                        String cuo = scanner.next();
                        System.out.print("Numero de habitacion: ");
                        String hab = scanner.next();
                        nodo.push("$" + cuo + " N: " + hab, "Mantenimiento");

                        System.out.print("\n¿Desea Agregar otro pago? 1.Si/2.No: ");
                    } while (scanner.nextInt() == 1);
                    System.out.println("\n*Guardado*");
                    break;
                case 4:
                    System.out.println("\nGestion de eventos");
                    do {
                        System.out.print("Escriba la fecha en que desea reservar DD/MM/YYYY: ");
                        String res = scanner.next();
                        System.out.print("Escriba su nombre: ");
                        String nom = scanner.next();
                        nodo.push("Nombre: " + nom + ": " + res, "Eventos");

                        System.out.print("\n¿Desea Agregar otra reserva? 1.Si/2.No: ");
                    } while (scanner.nextInt() == 1);
                    System.out.println("\n*Reservado*");
                    break;
                case 5:
                    do {
                        System.out.println("\nRegistro de visitas");
                        System.out.print("Escriba su nombre: ");
                        String nom = scanner.next();
                        System.out.print("Escriba la fecha en que visitara DD/MM/YYYY: ");
                        String fec = scanner.next();
                        System.out.print("Escriba el numero de habitacion de a quien visitara: ");
                        String num = scanner.next();
                        nodo.push("N:" + nom + " F:" + fec + " H:" + num, "Visitas");

                        System.out.print("\n¿Desea agregar otra visita? 1.Si/2.No: ");
                    } while (scanner.nextInt() == 1);
                    System.out.println("*Guardado*");
                    break;
                case 6:
                    System.out.println("\nLectura Agua y Luz");
                    do {
                        String tip = "";
                        do {
                            System.out.print("1.-Agua\n2.-Luz\n¿Que operacion desea realizar?:");
                            tip = scanner.next();
                        } while (tip.equalsIgnoreCase("3"));

                        String cat = (tip.equalsIgnoreCase("1") ? "M3" : "Kwh");
                        float aum = (float) (tip.equalsIgnoreCase("1") ? 15.0 : .25);
                        System.out.print("Escriba su lectura de " + cat + ": ");
                        float tot = aum * scanner.nextInt();
                        nodo.push("$" + tot + "", "Agua y Luz");

                        System.out.print("\n¿Desea Agregar otro pago? 1.Si/2.No: ");
                    } while (scanner.nextInt() == 1);
                    System.out.println("*Guardado*");
                    break;
                default:
                    System.out.println("Por favor escriba un valor correcto");
            }

            System.out.print("\nOperacion Finalizada"
                    + "\n¿Desea realizar otra operacion? "
                    + "1.Si/2.No: ");
        } while (scanner.nextInt() == 1);

        nodo.printLeft();
        do {
            System.out.print("1.-Imprimir lista de orden Descendente\n"
                    + "2.-Imprimir lista de orden Ascendente\n"
                    + "3.-Eliminar ultimo elemento\n"
                    + "4.-Eliminar primer elemento\n"
                    + "¿Que opcion quiere realizar?: ");
            int opc = scanner.nextInt();
            System.out.println("\n\n");
            switch (opc) {
                case 1:
                    nodo.printLeft();
                    break;
                case 2:
                    nodo.printRigth();
                    break;
                case 3:
                    System.out.println("Elemento eliminado: "+nodo.popFront());
                    nodo.printLeft();
                    break;
                case 4:
                    System.out.println("Elemento eliminado: "+nodo.popBack());
                    nodo.printLeft();
                    break;
                default:
                    System.out.println("Por favor escriba un valor correcto");
            }
            System.out.print("\nOperacion Realizada\n¿Desea hacer otra operacion? 1.Si/2.No: ");
        } while (scanner.nextInt() == 1);

        System.out.println("\n\n*FINALIZADO*");
    }

}
