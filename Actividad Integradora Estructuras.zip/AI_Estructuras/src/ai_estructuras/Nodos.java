package ai_estructuras;

public class Nodos {
    String info; //Donde se almacenara la informacion del nodo
    String type; //Donde se almacenara la categoria del nodo
    Nodos sig,ant; //Donde se enlazan los nodos
    
    public Nodos(String inf,String typ){
        info=inf;
        type=typ;
        sig=null;
        ant=null;
    }
}
